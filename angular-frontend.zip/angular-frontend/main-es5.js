(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/all-books/all-books.component.html":
/*!******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/all-books/all-books.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-12\">\n    <h1 class=\"text-center\" *ngIf=\"!isEdit\">All books</h1>\n    <h1 class=\"text-center\" *ngIf=\"isEdit\">Edit Book</h1>\n\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <div class=\"alert alert-warning\" *ngIf='invalid'>{{errorMessage}}</div>\n        <div class=\"alert alert-success\" *ngIf='success'>{{successMessage}}</div>\n     \n        <div *ngIf=\"isEdit\">\n            <form class=\"form-group\">\n                <div class=\"alert alert-warning\" *ngIf='invalidLogin'>{{errorMessage}}</div>\n                <div class=\"alert alert-success\" *ngIf='loginSuccess'>{{successMessage}}</div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Title :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.title\" placeholder=\"Book Title\"\n                    name=\"title\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Category :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.category\" placeholder=\"Book Category\"\n                    name=\"category\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Price :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"price\" [(ngModel)]=\"book.price\" placeholder=\"Book Price\"\n                    name=\"price\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Author :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.author\" placeholder=\"Book Author\"\n                    name=\"author\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Publisher :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"publisher\" [(ngModel)]=\"book.publisher\" placeholder=\"Book Publisher\"\n                    name=\"publisher\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Published Date :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.publishedDate\" placeholder=\"Book Publish Date\"\n                    name=\"publishedDate\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Chapters :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.chapters\" placeholder=\"Book Chapter\"\n                    name=\"chapters\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Active :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"active\" [(ngModel)]=\"book.active\" placeholder=\"Active\"\n                    name=\"active\">\n                </div>\n                <div class=\"form-group\">\n                  <label for=\"tile\">Book Id :</label>\n                  <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.bookId\" placeholder=\"Book Id\"\n                    name=\"bookId\">\n                </div>\n                \n                \n                <button (click)=handleEditBook(book) class=\"btn btn-success\">Update</button>\n               \n              </form>\n        </div>\n        <div style=\"overflow-x: auto;\" *ngIf=\"!isEdit\">\n            <table>\n              <tr>\n                <th>Title</th>\n                <th>Category</th>\n                <th>Price</th>\n                <th>Chapters</th>\n                <th>Author</th>\n                <th>Publisher</th>\n                <th>Published Date</th>\n                <th>Active</th>\n                <th></th>\n                <th></th>\n\n                \n              </tr>\n              <tr *ngFor=\"let book of books\">\n                <td>{{book.title}}</td>\n                <td>{{book.category}}</td>\n                <td>{{book.price}}</td>\n                <td>{{book.chapters}}</td>\n                <td>{{book.author}}</td>\n                <td>{{book.publisher}}</td>\n                <td>{{book.publishedDate}}</td>\n                <td>{{book.active}}</td>\n                <td>\n                    <div>\n                        <button class=\"btn btn-primary\" (click)=\"goToEditBook(book)\">Update</button>\n                    </div>\n                </td>\n                <td>\n                    <div *ngIf=\"!ifSubscribed(book)\">\n                        <button class=\"btn btn-danger\" (click)=\"handleSubscribe(book)\">Subscribe</button>\n                    </div>\n                    <div *ngIf=\"ifSubscribed(book)\">\n                      <button class=\"btn btn-success\" >Subscribed</button>\n                  </div>\n                </td>\n               \n              </tr>\n             \n            </table>\n          </div>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<router-outlet></router-outlet>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/create-book/create-book.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/create-book/create-book.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-6\">\n    <h1 class=\"text-center\">Create a book</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <form class=\"form-group\">\n            <div class=\"alert alert-warning\" *ngIf='invalid'>{{errorMessage}}</div>\n            <div class=\"alert alert-success\" *ngIf='success'>{{successMessage}}</div>\n            \n             <div class=\"form-group\">\n            <label for=\"tile\">Title :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.title\" placeholder=\"Book Title\"\n              name=\"title\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Category :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.category\" placeholder=\"Book Category\"\n              name=\"category\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Price :</label>\n            <input type=\"text\" class=\"form-control\" id=\"price\" [(ngModel)]=\"book.price\" placeholder=\"Book Price\"\n              name=\"price\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Author :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.author\" placeholder=\"Book Author\"\n              name=\"author\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Publisher :</label>\n            <input type=\"text\" class=\"form-control\" id=\"publisher\" [(ngModel)]=\"book.publisher\" placeholder=\"Book Publisher\"\n              name=\"publisher\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Published Date :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.publishedDate\" placeholder=\"Book Publish Date\"\n              name=\"publishedDate\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Chapters :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.chapters\" placeholder=\"Book Chapter\"\n              name=\"chapters\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Active :</label>\n            <input type=\"text\" class=\"form-control\" id=\"active\" [(ngModel)]=\"book.active\" placeholder=\"Active\"\n              name=\"active\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Book Id :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.bookId\" placeholder=\"Book Id\"\n              name=\"bookId\">\n          </div>\n          \n          \n          <button (click)=handleCreateBook() class=\"btn btn-success\">Create Book</button>\n        \n        </form>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/create/create.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/create/create.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>create works!</p>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/edit-book/edit-book.component.html":
/*!******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/edit-book/edit-book.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-6\">\n    <h1 class=\"text-center\">EditBook</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <form class=\"form-group\">\n          <div class=\"alert alert-warning\" *ngIf='invalidLogin'>{{errorMessage}}</div>\n          <div class=\"alert alert-success\" *ngIf='loginSuccess'>{{successMessage}}</div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Title :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.title\" placeholder=\"Book Title\"\n              name=\"title\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Category :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.category\" placeholder=\"Book Category\"\n              name=\"category\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Price :</label>\n            <input type=\"text\" class=\"form-control\" id=\"price\" [(ngModel)]=\"book.price\" placeholder=\"Book Price\"\n              name=\"price\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Author :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.author\" placeholder=\"Book Author\"\n              name=\"author\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Publisher :</label>\n            <input type=\"text\" class=\"form-control\" id=\"publisher\" [(ngModel)]=\"book.publisher\" placeholder=\"Book Publisher\"\n              name=\"publisher\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Published Date :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.publishedDate\" placeholder=\"Book Publish Date\"\n              name=\"publishedDate\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Chapters :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.chapters\" placeholder=\"Book Chapter\"\n              name=\"chapters\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Active :</label>\n            <input type=\"text\" class=\"form-control\" id=\"active\" [(ngModel)]=\"book.active\" placeholder=\"Active\"\n              name=\"active\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"tile\">Book Id :</label>\n            <input type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"book.bookId\" placeholder=\"Book Id\"\n              name=\"bookId\">\n          </div>\n          \n          \n          <button (click)=handleLogin() class=\"btn btn-success\">Login</button>\n          <div class=\"mt small link\" (click)=goToSignup()>\n            <span>Don't have account? Signup</span>\n          </div>\n        </form>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/hello-world/hello-world.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/hello-world/hello-world.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n\n<h1>{{message}}</h1>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/home-component/home-component.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home-component/home-component.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-6\">\n    <h1 class=\"text-center\">Welcome !</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <div class=\"row\">\n            <div class=\"col-md-6 book\">\n                <div class=\"bookBorder\" (click)=\"handleAllBooks()\">\n                    <img src='../../assets/all_books.jpg' height=\"150\" width=\"150\"/>\n                    <p>All books</p>\n                </div>\n            </div>\n            <div class=\"col-md-6 book\">\n                <div class=\"bookBorder\" (click)=\"handleCreateBook()\">\n                    <img src='../../assets/create_book.jpg' height=\"150\" width=\"150\"/>\n                    <p>Create a book</p>\n                </div>\n            </div>\n\n            <div class=\"col-md-6 book\">\n                <div class=\"bookBorder\">\n                    <img src='../../assets/search_book.jpg' (click)=\"handleSearchBook()\" height=\"150\" width=\"150\"/>\n                    <p>Search a book</p>\n                </div>\n            </div>\n\n        </div>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html":
/*!**********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-6\">\n    <h1 class=\"text-center\">Login</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <form class=\"form-group\">\n          <div class=\"alert alert-warning\" *ngIf='invalidLogin'>{{errorMessage}}</div>\n          <div class=\"alert alert-success\" *ngIf='loginSuccess'>{{successMessage}}</div>\n          <div class=\"form-group\">\n            <label for=\"email\">User Name :</label>\n            <input type=\"text\" class=\"form-control\" id=\"username\" [(ngModel)]=\"username\" placeholder=\"Enter User Name\"\n              name=\"username\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"pwd\">Password:</label>\n            <input type=\"password\" class=\"form-control\" [(ngModel)]=\"password\" id=\"password\" placeholder=\"Enter password\"\n              name=\"password\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"pwd\">Email:</label>\n            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"email\" id=\"email\" placeholder=\"Enter email\"\n              name=\"email\">\n          </div>\n          <button (click)=handleLogin() class=\"btn btn-success\">Login</button>\n          <div class=\"mt small link\" (click)=goToSignup()>\n            <span>Don't have account? Signup</span>\n          </div>\n        </form>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/logout/logout.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/logout/logout.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<h1>You are logged out</h1>\n<div class=\"container\">Thank You for Using Our Application.</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/menu/menu.component.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/menu/menu.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header>\n    <nav class=\"navbar navbar-expand-md navbar-dark bg-dark\">\n        <div *ngIf=\"isLoggedIn\"><a href=\"/home\" class=\"navbar-brand\">Digital Books</a></div>\n        <div *ngIf=\"!isLoggedIn\"><a href=\"#\" class=\"navbar-brand\">Digital Books</a></div>\n\n        <ul class=\"navbar-nav navbar-collapse justify-content-end\">\n            <!-- <li>\n                <a *ngIf=\"!isLoggedIn\" class=\"nav-link\" href=\"/login\">Login</a>\n            </li> -->\n            <li>\n                <a *ngIf=\"!isLoggedIn\" class=\"nav-link\" href=\"/login\" >login</a>\n\n            </li>\n            <li>\n                <a *ngIf=\"!isLoggedIn\" class=\"nav-link\" href=\"/signup\">Register</a>\n            </li>\n            <li>\n                <a *ngIf=\"isLoggedIn\" class=\"nav-link\" href=\"/logout\" (click)=handleLogout()>Logout</a>\n            </li>\n        </ul>\n    </nav>\n  </header>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/registration/signup.component.html":
/*!******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/registration/signup.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-6\">\n    <h1 class=\"text-center\">Sign up</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <form class=\"form-group\">\n          <div class=\"alert alert-warning\" *ngIf='invalidLogin'>{{errorMessage}}</div>\n          <div class=\"alert alert-success\" *ngIf='loginSuccess'>{{successMessage}}</div>\n          <div class=\"form-group\">\n            <label for=\"email\">User Name :</label>\n            <input type=\"text\" class=\"form-control\" id=\"username\" [(ngModel)]=\"username\" placeholder=\"Enter User Name\"\n              name=\"username\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"pwd\">Password:</label>\n            <input type=\"password\" class=\"form-control\" [(ngModel)]=\"password\" id=\"password\" placeholder=\"Enter password\"\n              name=\"password\">\n          </div>\n          <div class=\"form-group\">\n            <label for=\"pwd\">Email:</label>\n            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"email\" id=\"email\" placeholder=\"Enter email Id\"\n              name=\"email\">\n          </div>\n          <button (click)=handleLogin() class=\"btn btn-success\">Signup</button>\n        </form>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/search-book/search-book.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/search-book/search-book.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<div class=\"container col-lg-8\">\n    <h1 class=\"text-center\">Search Book</h1>\n    <div class=\"card\">\n      <div class=\"card-body\">\n        <form class=\"form-group\">\n           <div class=\"form-group\">\n            <label for=\"email\">Search :</label>\n            <input type=\"text\" class=\"form-control\" id=\"search\" [(ngModel)]=\"keyword\" placeholder=\"Search keyword\"\n              name=\"search\">\n          </div>\n          <button (click)=handleSearch() class=\"btn btn-success\">Search</button>\n         \n        </form>\n      </div>\n      <div style=\"overflow-x: auto;\" *ngIf=\"found == 1\" >\n        <table>\n          <tr>\n            <th>Title</th>\n            <th>Category</th>\n            <th>Price</th>\n            <th>Chapters</th>\n            <th>Author</th>\n            <th>Publisher</th>\n            <th>Published Date</th>\n            <th>Active</th>\n          \n\n            \n          </tr>\n          <tr *ngFor=\"let book of books\">\n            <td>{{book.title}}</td>\n            <td>{{book.category}}</td>\n            <td>{{book.price}}</td>\n            <td>{{book.chapters}}</td>\n            <td>{{book.author}}</td>\n            <td>{{book.publisher}}</td>\n            <td>{{book.publishedDate}}</td>\n            <td>{{book.Active}}</td>\n          \n           \n          </tr>\n         \n        </table>\n      </div>\n      <div *ngIf=\"found == 2\">\n        <span>No book found</span>\n      </div>\n    </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/all-books/all-books.component.css":
/*!***************************************************!*\
  !*** ./src/app/all-books/all-books.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    border-collapse: collapse;\n    width: 100%;\n  }\n  \n  th, td {\n    text-align: left;\n    padding: 8px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWxsLWJvb2tzL2FsbC1ib29rcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0kseUJBQXlCO0lBQ3pCLFdBQVc7RUFDYjs7RUFFQTtJQUNFLGdCQUFnQjtJQUNoQixZQUFZO0VBQ2Q7O0VBRUEsb0JBQW9CLHlCQUF5QixDQUFDIiwiZmlsZSI6InNyYy9hcHAvYWxsLWJvb2tzL2FsbC1ib29rcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbiAgXG4gIHRoLCB0ZCB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgXG4gIHRyOm50aC1jaGlsZChldmVuKSB7YmFja2dyb3VuZC1jb2xvcjogI2YyZjJmMjt9Il19 */"

/***/ }),

/***/ "./src/app/all-books/all-books.component.ts":
/*!**************************************************!*\
  !*** ./src/app/all-books/all-books.component.ts ***!
  \**************************************************/
/*! exports provided: AllBooksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllBooksComponent", function() { return AllBooksComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _book_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../book.service */ "./src/app/book.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login/auth.service */ "./src/app/login/auth.service.ts");





var AllBooksComponent = /** @class */ (function () {
    function AllBooksComponent(BookService, route, router, auth) {
        this.BookService = BookService;
        this.route = route;
        this.router = router;
        this.auth = auth;
        this.book = {
            logo: '',
            title: '',
            category: '',
            price: '',
            author: '',
            publisher: '',
            publishedDate: '',
            chapters: '',
            active: '',
            bookId: ''
        };
        this.isEdit = false;
        this.errorMessage = 'Cannot subscribe a book. Please try again';
        this.invalid = false;
        this.success = false;
    }
    AllBooksComponent.prototype.ngOnInit = function () {
        this.GetAllBooks();
        this.GetAllSubscribedBooks();
    };
    AllBooksComponent.prototype.GetAllBooks = function () {
        var _this = this;
        this.BookService.GetAllBooks().subscribe(function (result) {
            _this.books = result;
            _this.books = _this.books.filter(function (x) { return x.bookId != undefined && x.bookId != ""; });
        }, function () {
            _this.invalid = true;
            _this.success = false;
            _this.errorMessage = 'Cannot fetch books. Please try again';
        });
    };
    AllBooksComponent.prototype.GetAllSubscribedBooks = function () {
        var _this = this;
        this.BookService.getSubscribedBooks(this.auth.getLoggedInUserEmail()).subscribe(function (result) {
            _this.subscribed = result;
            console.log(_this.subscribed);
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
    };
    AllBooksComponent.prototype.goToEditBook = function (book) {
        this.book = book;
        this.isEdit = true;
    };
    AllBooksComponent.prototype.handleEditBook = function (book) {
        this.BookService.EditBook(book).subscribe(function (result) {
            console.log(result);
            window.location.reload();
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
    };
    AllBooksComponent.prototype.ifSubscribed = function (book) {
        if (this.subscribed != undefined) {
            var found = this.subscribed.find(function (element) { return element != null && element.bookId == book.bookId; });
            console.log(found);
            if (found != null) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    AllBooksComponent.prototype.handleSubscribe = function (book) {
        var _this = this;
        console.log(book);
        this.BookService.SubscribeBook(book, this.auth.getLoggedInUserEmail(), this.auth.getLoggedInUserName()).subscribe(function (result) {
            console.log("hi");
            if (result.includes("subscribed")) {
                _this.invalid = false;
                _this.success = true;
                _this.successMessage = result;
                window.location.reload();
            }
            else {
                _this.invalid = true;
                _this.success = false;
                _this.errorMessage = 'Cannot fetch books. Please try again';
            }
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
        window.location.reload();
    };
    AllBooksComponent.ctorParameters = function () { return [
        { type: _book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"] }
    ]; };
    AllBooksComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-all-books',
            template: __webpack_require__(/*! raw-loader!./all-books.component.html */ "./node_modules/raw-loader/index.js!./src/app/all-books/all-books.component.html"),
            styles: [__webpack_require__(/*! ./all-books.component.css */ "./src/app/all-books/all-books.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]])
    ], AllBooksComponent);
    return AllBooksComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _hello_world_hello_world_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./hello-world/hello-world.component */ "./src/app/hello-world/hello-world.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _registration_signup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./registration/signup.component */ "./src/app/registration/signup.component.ts");
/* harmony import */ var _home_component_home_component_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-component/home-component.component */ "./src/app/home-component/home-component.component.ts");
/* harmony import */ var _all_books_all_books_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./all-books/all-books.component */ "./src/app/all-books/all-books.component.ts");
/* harmony import */ var _edit_book_edit_book_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./edit-book/edit-book.component */ "./src/app/edit-book/edit-book.component.ts");
/* harmony import */ var _create_book_create_book_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./create-book/create-book.component */ "./src/app/create-book/create-book.component.ts");
/* harmony import */ var _search_book_search_book_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./search-book/search-book.component */ "./src/app/search-book/search-book.component.ts");











var routes = [
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"] },
    { path: '', component: _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"] },
    { path: 'hello-world', component: _hello_world_hello_world_component__WEBPACK_IMPORTED_MODULE_3__["HelloWorldComponent"] },
    { path: 'logout', component: _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"] },
    { path: 'signup', component: _registration_signup_component__WEBPACK_IMPORTED_MODULE_5__["SignupComponent"] },
    { path: 'home', component: _home_component_home_component_component__WEBPACK_IMPORTED_MODULE_6__["HomeComponentComponent"] },
    { path: 'allbooks', component: _all_books_all_books_component__WEBPACK_IMPORTED_MODULE_7__["AllBooksComponent"] },
    { path: 'book/:id', component: _edit_book_edit_book_component__WEBPACK_IMPORTED_MODULE_8__["EditBookComponent"] },
    { path: 'create', component: _create_book_create_book_component__WEBPACK_IMPORTED_MODULE_9__["CreateBookComponent"] },
    { path: 'search', component: _search_book_search_book_component__WEBPACK_IMPORTED_MODULE_10__["SearchBookComponent"] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'angular-frontend';
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _hello_world_hello_world_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./hello-world/hello-world.component */ "./src/app/hello-world/hello-world.component.ts");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./menu/menu.component */ "./src/app/menu/menu.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _registration_signup_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./registration/signup.component */ "./src/app/registration/signup.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _logout_logout_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./logout/logout.component */ "./src/app/logout/logout.component.ts");
/* harmony import */ var _httpInterceptor_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./httpInterceptor.service */ "./src/app/httpInterceptor.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _home_component_home_component_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./home-component/home-component.component */ "./src/app/home-component/home-component.component.ts");
/* harmony import */ var _create_create_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./create/create.component */ "./src/app/create/create.component.ts");
/* harmony import */ var _create_book_create_book_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./create-book/create-book.component */ "./src/app/create-book/create-book.component.ts");
/* harmony import */ var _all_books_all_books_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./all-books/all-books.component */ "./src/app/all-books/all-books.component.ts");
/* harmony import */ var _search_book_search_book_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./search-book/search-book.component */ "./src/app/search-book/search-book.component.ts");
/* harmony import */ var _edit_book_edit_book_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./edit-book/edit-book.component */ "./src/app/edit-book/edit-book.component.ts");



















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _hello_world_hello_world_component__WEBPACK_IMPORTED_MODULE_5__["HelloWorldComponent"],
                _menu_menu_component__WEBPACK_IMPORTED_MODULE_6__["MenuComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_7__["LoginComponent"],
                _logout_logout_component__WEBPACK_IMPORTED_MODULE_10__["LogoutComponent"],
                _registration_signup_component__WEBPACK_IMPORTED_MODULE_8__["SignupComponent"],
                _home_component_home_component_component__WEBPACK_IMPORTED_MODULE_13__["HomeComponentComponent"],
                _create_create_component__WEBPACK_IMPORTED_MODULE_14__["CreateComponent"],
                _create_book_create_book_component__WEBPACK_IMPORTED_MODULE_15__["CreateBookComponent"],
                _all_books_all_books_component__WEBPACK_IMPORTED_MODULE_16__["AllBooksComponent"],
                _search_book_search_book_component__WEBPACK_IMPORTED_MODULE_17__["SearchBookComponent"],
                _edit_book_edit_book_component__WEBPACK_IMPORTED_MODULE_18__["EditBookComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"]
            ],
            providers: [
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HTTP_INTERCEPTORS"],
                    useClass: _httpInterceptor_service__WEBPACK_IMPORTED_MODULE_11__["HttpInterceptorService"],
                    multi: true
                }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/book.service.ts":
/*!*********************************!*\
  !*** ./src/app/book.service.ts ***!
  \*********************************/
/*! exports provided: BookService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookService", function() { return BookService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./login/auth.service */ "./src/app/login/auth.service.ts");





var BookService = /** @class */ (function () {
    function BookService(http, auth) {
        this.http = http;
        this.auth = auth;
    }
    BookService.prototype.GetAllBooks = function () {
        return this.http.get('http://3.7.252.163:9999/api/v1/digitalbooks/findAll', { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } });
    };
    BookService.prototype.CreateBook = function (email, book) {
        console.log(email);
        return this.http.post('http://3.7.252.163:9999/api/v1/digitalbooks/author/books/' + email, book, { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res;
        }));
    };
    BookService.prototype.EditBook = function (book) {
        return this.http.put('http://3.7.252.163:9999/api/v1/digitalbooks/author/' + book.bookId, book, { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res;
        }));
    };
    BookService.prototype.SubscribeBook = function (book, email, name) {
        var subscription = {
            bookId: book.bookId,
            emailId: email,
            name: name
        };
        return this.http.post('http://3.7.252.163:9999/api/v1/digitalbooks/books/subscribe', subscription, { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res;
        }));
    };
    BookService.prototype.SearchBook = function (keyword) {
        return this.http.get('http://3.7.252.163:9999/api/v1/digitalbooks/books/search/' + keyword, { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } });
    };
    BookService.prototype.getSubscribedBooks = function (email) {
        return this.http.get('http://3.7.252.163:9999/api/v1/digitalbooks/books/' + email, { headers: { Authorization: 'Bearer ' + this.auth.getLoggedInToken() } });
    };
    BookService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"] }
    ]; };
    BookService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]])
    ], BookService);
    return BookService;
}());



/***/ }),

/***/ "./src/app/create-book/create-book.component.css":
/*!*******************************************************!*\
  !*** ./src/app/create-book/create-book.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NyZWF0ZS1ib29rL2NyZWF0ZS1ib29rLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/create-book/create-book.component.ts":
/*!******************************************************!*\
  !*** ./src/app/create-book/create-book.component.ts ***!
  \******************************************************/
/*! exports provided: CreateBookComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateBookComponent", function() { return CreateBookComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _book_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../book.service */ "./src/app/book.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login/auth.service */ "./src/app/login/auth.service.ts");





var CreateBookComponent = /** @class */ (function () {
    function CreateBookComponent(BookService, route, router, auth) {
        this.BookService = BookService;
        this.route = route;
        this.router = router;
        this.auth = auth;
        this.book = {
            logo: '',
            title: '',
            category: '',
            price: '',
            author: '',
            publisher: '',
            publishedDate: '',
            chapters: '',
            active: '',
            bookId: ''
        };
        this.errorMessage = 'Cannot Creat a book. Please try again';
        this.invalid = false;
        this.success = false;
    }
    CreateBookComponent.prototype.ngOnInit = function () {
    };
    CreateBookComponent.prototype.handleCreateBook = function () {
        var _this = this;
        console.log(this.book);
        if (this.book.title != '') {
            this.BookService.CreateBook(this.auth.getLoggedInUserEmail(), this.book).subscribe(function (result) {
                if (result.message.includes("create")) {
                    _this.invalid = false;
                    _this.success = true;
                    _this.successMessage = result.message;
                }
            }, function () {
                _this.invalid = true;
                _this.success = false;
                _this.errorMessage = 'Cannot Creat a book. Please try again';
            });
        }
        else {
            this.invalid = true;
            this.success = false;
            this.errorMessage = 'Cannot Creat a book. Please try again';
        }
    };
    CreateBookComponent.ctorParameters = function () { return [
        { type: _book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"] }
    ]; };
    CreateBookComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-create-book',
            template: __webpack_require__(/*! raw-loader!./create-book.component.html */ "./node_modules/raw-loader/index.js!./src/app/create-book/create-book.component.html"),
            styles: [__webpack_require__(/*! ./create-book.component.css */ "./src/app/create-book/create-book.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _login_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]])
    ], CreateBookComponent);
    return CreateBookComponent;
}());



/***/ }),

/***/ "./src/app/create/create.component.css":
/*!*********************************************!*\
  !*** ./src/app/create/create.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NyZWF0ZS9jcmVhdGUuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/create/create.component.ts":
/*!********************************************!*\
  !*** ./src/app/create/create.component.ts ***!
  \********************************************/
/*! exports provided: CreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateComponent", function() { return CreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var CreateComponent = /** @class */ (function () {
    function CreateComponent() {
    }
    CreateComponent.prototype.ngOnInit = function () {
    };
    CreateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-create',
            template: __webpack_require__(/*! raw-loader!./create.component.html */ "./node_modules/raw-loader/index.js!./src/app/create/create.component.html"),
            styles: [__webpack_require__(/*! ./create.component.css */ "./src/app/create/create.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CreateComponent);
    return CreateComponent;
}());



/***/ }),

/***/ "./src/app/edit-book/edit-book.component.css":
/*!***************************************************!*\
  !*** ./src/app/edit-book/edit-book.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VkaXQtYm9vay9lZGl0LWJvb2suY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/edit-book/edit-book.component.ts":
/*!**************************************************!*\
  !*** ./src/app/edit-book/edit-book.component.ts ***!
  \**************************************************/
/*! exports provided: EditBookComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditBookComponent", function() { return EditBookComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _book_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../book.service */ "./src/app/book.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var EditBookComponent = /** @class */ (function () {
    function EditBookComponent(BookService, route, router) {
        this.BookService = BookService;
        this.route = route;
        this.router = router;
        this.book = {
            logo: '',
            title: '',
            category: '',
            price: '',
            author: '',
            publisher: '',
            publishedDate: '',
            chapters: '',
            active: '',
            bookId: ''
        };
    }
    EditBookComponent.prototype.ngOnInit = function () {
    };
    EditBookComponent.prototype.handleInitBook = function () {
        console.log(this.book);
        this.BookService.EditBook(this.book).subscribe(function (result) {
            console.log(result);
        }, function () {
        });
    };
    EditBookComponent.ctorParameters = function () { return [
        { type: _book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
    ]; };
    EditBookComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edit-book',
            template: __webpack_require__(/*! raw-loader!./edit-book.component.html */ "./node_modules/raw-loader/index.js!./src/app/edit-book/edit-book.component.html"),
            styles: [__webpack_require__(/*! ./edit-book.component.css */ "./src/app/edit-book/edit-book.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], EditBookComponent);
    return EditBookComponent;
}());



/***/ }),

/***/ "./src/app/hello-word.service.ts":
/*!***************************************!*\
  !*** ./src/app/hello-word.service.ts ***!
  \***************************************/
/*! exports provided: HelloWordService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelloWordService", function() { return HelloWordService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var HelloWordService = /** @class */ (function () {
    function HelloWordService(http) {
        this.http = http;
    }
    HelloWordService.prototype.helloWorldService = function () {
        //const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa('javaguides' + ':' + 'password') });
        return this.http.get('http://localhost:8080/api/v1/greeting');
    };
    HelloWordService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    HelloWordService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], HelloWordService);
    return HelloWordService;
}());



/***/ }),

/***/ "./src/app/hello-world/hello-world.component.css":
/*!*******************************************************!*\
  !*** ./src/app/hello-world/hello-world.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hlbGxvLXdvcmxkL2hlbGxvLXdvcmxkLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/hello-world/hello-world.component.ts":
/*!******************************************************!*\
  !*** ./src/app/hello-world/hello-world.component.ts ***!
  \******************************************************/
/*! exports provided: HelloWorldComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelloWorldComponent", function() { return HelloWorldComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _hello_word_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hello-word.service */ "./src/app/hello-word.service.ts");



var HelloWorldComponent = /** @class */ (function () {
    function HelloWorldComponent(helloWorldService) {
        this.helloWorldService = helloWorldService;
    }
    HelloWorldComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("HelloWorldComponent");
        this.helloWorldService.helloWorldService().subscribe(function (result) {
            _this.message = result.content;
        });
    };
    HelloWorldComponent.ctorParameters = function () { return [
        { type: _hello_word_service__WEBPACK_IMPORTED_MODULE_2__["HelloWordService"] }
    ]; };
    HelloWorldComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-hello-world',
            template: __webpack_require__(/*! raw-loader!./hello-world.component.html */ "./node_modules/raw-loader/index.js!./src/app/hello-world/hello-world.component.html"),
            styles: [__webpack_require__(/*! ./hello-world.component.css */ "./src/app/hello-world/hello-world.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_hello_word_service__WEBPACK_IMPORTED_MODULE_2__["HelloWordService"]])
    ], HelloWorldComponent);
    return HelloWorldComponent;
}());



/***/ }),

/***/ "./src/app/home-component/home-component.component.css":
/*!*************************************************************!*\
  !*** ./src/app/home-component/home-component.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".book {\n    text-align: center;\n    margin-left: auto;\n    margin-right: auto;\n    cursor: pointer;\n}\n.bookBorder{\n    padding-top:22px;\n}\nimg{\n    border:2px solid black;\n\n}\n.bookBorder p {\n    font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS1jb21wb25lbnQvaG9tZS1jb21wb25lbnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkI7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksc0JBQXNCOztBQUUxQjtBQUVBO0lBQ0ksZUFBZTtBQUNuQiIsImZpbGUiOiJzcmMvYXBwL2hvbWUtY29tcG9uZW50L2hvbWUtY29tcG9uZW50LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm9vayB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICAgIG1hcmdpbi1yaWdodDogYXV0bztcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG4uYm9va0JvcmRlcntcbiAgICBwYWRkaW5nLXRvcDoyMnB4O1xufVxuaW1ne1xuICAgIGJvcmRlcjoycHggc29saWQgYmxhY2s7XG5cbn1cblxuLmJvb2tCb3JkZXIgcCB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/home-component/home-component.component.ts":
/*!************************************************************!*\
  !*** ./src/app/home-component/home-component.component.ts ***!
  \************************************************************/
/*! exports provided: HomeComponentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponentComponent", function() { return HomeComponentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var HomeComponentComponent = /** @class */ (function () {
    function HomeComponentComponent(route, router) {
        this.route = route;
        this.router = router;
    }
    HomeComponentComponent.prototype.ngOnInit = function () {
    };
    HomeComponentComponent.prototype.handleAllBooks = function () {
        this.router.navigate(['/allbooks']);
    };
    HomeComponentComponent.prototype.handleCreateBook = function () {
        this.router.navigate(['/create']);
    };
    HomeComponentComponent.prototype.handleSearchBook = function () {
        this.router.navigate(['/search']);
    };
    HomeComponentComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    HomeComponentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home-component',
            template: __webpack_require__(/*! raw-loader!./home-component.component.html */ "./node_modules/raw-loader/index.js!./src/app/home-component/home-component.component.html"),
            styles: [__webpack_require__(/*! ./home-component.component.css */ "./src/app/home-component/home-component.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HomeComponentComponent);
    return HomeComponentComponent;
}());



/***/ }),

/***/ "./src/app/httpInterceptor.service.ts":
/*!********************************************!*\
  !*** ./src/app/httpInterceptor.service.ts ***!
  \********************************************/
/*! exports provided: HttpInterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpInterceptorService", function() { return HttpInterceptorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login/auth.service */ "./src/app/login/auth.service.ts");



var HttpInterceptorService = /** @class */ (function () {
    function HttpInterceptorService(authenticationService) {
        this.authenticationService = authenticationService;
    }
    HttpInterceptorService.prototype.intercept = function (req, next) {
        if (this.authenticationService.isUserLoggedIn() && req.url.indexOf('basicauth') === -1) {
            var authReq = req.clone({
                headers: req.headers
            });
            return next.handle(authReq);
        }
        else {
            return next.handle(req);
        }
    };
    HttpInterceptorService.ctorParameters = function () { return [
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }
    ]; };
    HttpInterceptorService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_login_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], HttpInterceptorService);
    return HttpInterceptorService;
}());



/***/ }),

/***/ "./src/app/login/auth.service.ts":
/*!***************************************!*\
  !*** ./src/app/login/auth.service.ts ***!
  \***************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");




var AuthenticationService = /** @class */ (function () {
    function AuthenticationService(http) {
        this.http = http;
        // BASE_PATH: 'http://3.7.252.163:8080'
        this.USER_NAME_SESSION_ATTRIBUTE_NAME = '';
        this.USER_NAME_SESSION_ATTRIBUTE_EMAIL = '';
        this.USER_NAME_SESSION_ATTRIBUTE_TOKEN = '';
        this.user = {
            username: '',
            password: '',
            emailId: '',
        };
        this.register = {
            name: '',
            password: '',
            emailId: '',
        };
    }
    AuthenticationService.prototype.authenticationService = function (username, password, email) {
        var _this = this;
        this.user.username = username;
        this.user.password = password;
        this.user.emailId = email;
        return this.http.post("http://3.7.252.163:9999/api/v1/digitalbooks/authenticate", this.user).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            _this.username = username;
            _this.password = password;
            _this.email = email;
            _this.token = res.token;
            console.log(email);
            _this.registerSuccessfulLogin(username, password, _this.token, email);
            return res;
        }));
    };
    AuthenticationService.prototype.registerationService = function (username, password, email) {
        this.register.name = username;
        this.register.password = password;
        this.register.emailId = email;
        return this.http.post("http://3.7.252.163:9999/api/v1/digitalbooks/author/signup", this.register).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (res) {
            return res;
        }));
    };
    AuthenticationService.prototype.createBasicAuthToken = function (username, password) {
        return 'Basic ' + window.btoa(username + ":" + password);
    };
    AuthenticationService.prototype.registerSuccessfulLogin = function (username, password, token, email) {
        sessionStorage.setItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME, username);
        localStorage.setItem(this.USER_NAME_SESSION_ATTRIBUTE_EMAIL, email);
        sessionStorage.setItem(this.USER_NAME_SESSION_ATTRIBUTE_TOKEN, token);
        console.log(email);
        console.log(localStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_EMAIL));
    };
    AuthenticationService.prototype.logout = function () {
        sessionStorage.removeItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
        localStorage.removeItem(this.USER_NAME_SESSION_ATTRIBUTE_EMAIL);
        sessionStorage.removeItem(this.USER_NAME_SESSION_ATTRIBUTE_TOKEN);
        this.username = null;
        this.password = null;
    };
    AuthenticationService.prototype.isUserLoggedIn = function () {
        var user = sessionStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
        if (user === null)
            return false;
        return true;
    };
    AuthenticationService.prototype.getLoggedInUserName = function () {
        var user = sessionStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_NAME);
        if (user === null)
            return '';
        return user;
    };
    AuthenticationService.prototype.getLoggedInUserEmail = function () {
        var user = localStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_EMAIL);
        if (user === null)
            return '';
        return user;
    };
    AuthenticationService.prototype.getLoggedInToken = function () {
        var user = sessionStorage.getItem(this.USER_NAME_SESSION_ATTRIBUTE_TOKEN);
        if (user === null)
            return '';
        return user;
    };
    AuthenticationService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
    ]; };
    AuthenticationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], AuthenticationService);
    return AuthenticationService;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mt{\n    margin-top:10px;\n}\n.small{\n    font-size: 12px !important;\n    font-weight: 500 !important;\n    text-align: end !important;\n}\n.link {\n    cursor: pointer;\n    color:blue;\n    \n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGVBQWU7QUFDbkI7QUFDQTtJQUNJLDBCQUEwQjtJQUMxQiwyQkFBMkI7SUFDM0IsMEJBQTBCO0FBQzlCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsVUFBVTs7QUFFZCIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXR7XG4gICAgbWFyZ2luLXRvcDoxMHB4O1xufVxuLnNtYWxse1xuICAgIGZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDAgIWltcG9ydGFudDtcbiAgICB0ZXh0LWFsaWduOiBlbmQgIWltcG9ydGFudDtcbn1cbi5saW5rIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgY29sb3I6Ymx1ZTtcbiAgICBcbn0iXX0= */"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/login/auth.service.ts");




var LoginComponent = /** @class */ (function () {
    function LoginComponent(route, router, authenticationService) {
        this.route = route;
        this.router = router;
        this.authenticationService = authenticationService;
        this.errorMessage = 'Invalid Credentials';
        this.invalidLogin = false;
        this.loginSuccess = false;
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent.prototype.handleLogin = function () {
        var _this = this;
        if (this.email !== undefined) {
            this.authenticationService.authenticationService(this.username, this.password, this.email).subscribe(function (result) {
                console.log(result.message);
                if (new String(result.message).valueOf() != new String("invalid user").valueOf()) {
                    _this.invalidLogin = false;
                    _this.loginSuccess = true;
                    _this.successMessage = 'Login Successful';
                    _this.router.navigate(['/home']);
                }
                else {
                    _this.invalidLogin = true;
                    _this.loginSuccess = false;
                }
            }, function () {
                _this.invalidLogin = true;
                _this.loginSuccess = false;
            });
        }
        else {
            this.invalidLogin = true;
            this.loginSuccess = false;
        }
    };
    LoginComponent.prototype.goToSignup = function () {
        this.router.navigate(['/signup']);
    };
    LoginComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }
    ]; };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/logout/logout.component.css":
/*!*********************************************!*\
  !*** ./src/app/logout/logout.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ291dC9sb2dvdXQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/logout/logout.component.ts":
/*!********************************************!*\
  !*** ./src/app/logout/logout.component.ts ***!
  \********************************************/
/*! exports provided: LogoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogoutComponent", function() { return LogoutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LogoutComponent = /** @class */ (function () {
    function LogoutComponent() {
    }
    LogoutComponent.prototype.ngOnInit = function () {
    };
    LogoutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-logout',
            template: __webpack_require__(/*! raw-loader!./logout.component.html */ "./node_modules/raw-loader/index.js!./src/app/logout/logout.component.html"),
            styles: [__webpack_require__(/*! ./logout.component.css */ "./src/app/logout/logout.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LogoutComponent);
    return LogoutComponent;
}());



/***/ }),

/***/ "./src/app/menu/menu.component.css":
/*!*****************************************!*\
  !*** ./src/app/menu/menu.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbnUvbWVudS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/menu/menu.component.ts":
/*!****************************************!*\
  !*** ./src/app/menu/menu.component.ts ***!
  \****************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../login/auth.service */ "./src/app/login/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var MenuComponent = /** @class */ (function () {
    function MenuComponent(route, router, authenticationService) {
        this.route = route;
        this.router = router;
        this.authenticationService = authenticationService;
        this.isLoggedIn = false;
    }
    MenuComponent.prototype.ngOnInit = function () {
        this.isLoggedIn = this.authenticationService.isUserLoggedIn();
        console.log('menu ->' + this.isLoggedIn);
    };
    MenuComponent.prototype.handleLogout = function () {
        this.authenticationService.logout();
    };
    MenuComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }
    ]; };
    MenuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__(/*! raw-loader!./menu.component.html */ "./node_modules/raw-loader/index.js!./src/app/menu/menu.component.html"),
            styles: [__webpack_require__(/*! ./menu.component.css */ "./src/app/menu/menu.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _login_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ }),

/***/ "./src/app/registration/signup.component.css":
/*!***************************************************!*\
  !*** ./src/app/registration/signup.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mt{\n    margin-top:10px;\n}\n.small{\n    font-size: 10px;\n}\n.link {\n    cursor: pointer;\n    color:blue;\n    \n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0cmF0aW9uL3NpZ251cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZUFBZTtBQUNuQjtBQUNBO0lBQ0ksZUFBZTtBQUNuQjtBQUNBO0lBQ0ksZUFBZTtJQUNmLFVBQVU7O0FBRWQiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3RyYXRpb24vc2lnbnVwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXR7XG4gICAgbWFyZ2luLXRvcDoxMHB4O1xufVxuLnNtYWxse1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbn1cbi5saW5rIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgY29sb3I6Ymx1ZTtcbiAgICBcbn0iXX0= */"

/***/ }),

/***/ "./src/app/registration/signup.component.ts":
/*!**************************************************!*\
  !*** ./src/app/registration/signup.component.ts ***!
  \**************************************************/
/*! exports provided: SignupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupComponent", function() { return SignupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../login/auth.service */ "./src/app/login/auth.service.ts");




var SignupComponent = /** @class */ (function () {
    function SignupComponent(route, router, authenticationService) {
        this.route = route;
        this.router = router;
        this.authenticationService = authenticationService;
        this.errorMessage = 'Cannot create account';
        this.invalidLogin = false;
        this.loginSuccess = false;
    }
    SignupComponent.prototype.ngOnInit = function () {
    };
    SignupComponent.prototype.handleLogin = function () {
        var _this = this;
        this.authenticationService.registerationService(this.username, this.password, this.email).subscribe(function (result) {
            if (_this.username != undefined && _this.email != undefined && _this.password != undefined) {
                _this.invalidLogin = false;
                _this.loginSuccess = true;
                _this.successMessage = "Account Created Successfully";
            }
            else {
                _this.invalidLogin = true;
                _this.loginSuccess = false;
                _this.successMessage = "Account Cannot be created";
            }
            //    this.router.navigate(['/hello-world']);
        }, function () {
            if (_this.username != undefined && _this.email != undefined && _this.password != undefined) {
                _this.invalidLogin = false;
                _this.loginSuccess = true;
                _this.successMessage = "Account Created Successfully";
            }
            else {
                _this.invalidLogin = true;
                _this.loginSuccess = false;
                _this.successMessage = "Account Cannot be created";
            }
        });
    };
    SignupComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _login_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }
    ]; };
    SignupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-signup',
            template: __webpack_require__(/*! raw-loader!./signup.component.html */ "./node_modules/raw-loader/index.js!./src/app/registration/signup.component.html"),
            styles: [__webpack_require__(/*! ./signup.component.css */ "./src/app/registration/signup.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _login_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])
    ], SignupComponent);
    return SignupComponent;
}());



/***/ }),

/***/ "./src/app/search-book/search-book.component.css":
/*!*******************************************************!*\
  !*** ./src/app/search-book/search-book.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n    border-collapse: collapse;\n    width: 100%;\n  }\n  \n  th, td {\n    text-align: left;\n    padding: 8px;\n  }\n  \n  tr:nth-child(even) {background-color: #f2f2f2;}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoLWJvb2svc2VhcmNoLWJvb2suY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHlCQUF5QjtJQUN6QixXQUFXO0VBQ2I7O0VBRUE7SUFDRSxnQkFBZ0I7SUFDaEIsWUFBWTtFQUNkOztFQUVBLG9CQUFvQix5QkFBeUIsQ0FBQyIsImZpbGUiOiJzcmMvYXBwL3NlYXJjaC1ib29rL3NlYXJjaC1ib29rLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ0YWJsZSB7XG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuICBcbiAgdGgsIHRkIHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIHBhZGRpbmc6IDhweDtcbiAgfVxuICBcbiAgdHI6bnRoLWNoaWxkKGV2ZW4pIHtiYWNrZ3JvdW5kLWNvbG9yOiAjZjJmMmYyO30iXX0= */"

/***/ }),

/***/ "./src/app/search-book/search-book.component.ts":
/*!******************************************************!*\
  !*** ./src/app/search-book/search-book.component.ts ***!
  \******************************************************/
/*! exports provided: SearchBookComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBookComponent", function() { return SearchBookComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _book_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../book.service */ "./src/app/book.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var SearchBookComponent = /** @class */ (function () {
    function SearchBookComponent(BookService, route, router) {
        this.BookService = BookService;
        this.route = route;
        this.router = router;
        this.found = 0;
        this.book = {
            logo: '',
            title: '',
            category: '',
            price: '',
            author: '',
            publisher: '',
            publishedDate: '',
            chapters: '',
            active: '',
            bookId: ''
        };
        this.isEdit = false;
    }
    SearchBookComponent.prototype.ngOnInit = function () {
    };
    SearchBookComponent.prototype.handleSearch = function () {
        var _this = this;
        this.BookService.SearchBook(this.keyword).subscribe(function (result) {
            _this.books = result;
            console.log(_this.books);
            if (_this.books != null && _this.books.length > 0) {
                _this.found = 1;
            }
            else {
                _this.found = 2;
            }
            console.log(_this.books);
            console.log(_this.books.length);
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
    };
    SearchBookComponent.prototype.goToEditBook = function (book) {
        this.book = book;
        this.isEdit = true;
    };
    SearchBookComponent.prototype.handleEditBook = function (book) {
        this.BookService.EditBook(book).subscribe(function (result) {
            console.log(result);
            window.location.reload();
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
    };
    SearchBookComponent.prototype.handleSubscribe = function (book) {
        this.BookService.SubscribeBook(book, "abc@abc.com", "hiba").subscribe(function (result) {
            console.log(result);
            window.location.reload();
            //  this.successMessage = 'Login Successful.';
        }, function () {
        });
    };
    SearchBookComponent.ctorParameters = function () { return [
        { type: _book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
    ]; };
    SearchBookComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-search-book',
            template: __webpack_require__(/*! raw-loader!./search-book.component.html */ "./node_modules/raw-loader/index.js!./src/app/search-book/search-book.component.html"),
            styles: [__webpack_require__(/*! ./search-book.component.css */ "./src/app/search-book/search-book.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], SearchBookComponent);
    return SearchBookComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\cogjava2209\Desktop\hiba\digital_books-master\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es5.js.map